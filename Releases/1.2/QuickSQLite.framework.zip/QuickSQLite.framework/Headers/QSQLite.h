//
//  QSQLite.h
//  QuickSQLite
//
//  Created by sudi on 2016/12/15.
//
//

#ifndef QSQLite_h
#define QSQLite_h

#import "QDBValue.h"
#import "QSQLiteOpenHelper.h"

#define QSTR(s, ...) ([NSString stringWithFormat:(s), ##__VA_ARGS__ ?:@""])

#endif /* QSQLite_h */
