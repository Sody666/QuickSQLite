//
//  staticLibrary.h
//  staticLibrary
//
//  Created by sudi on 2016/12/15.
//
//

#import <Foundation/Foundation.h>

@interface staticLibrary : NSObject

@end
